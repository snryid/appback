<?php

return [

    'template'         => [
        // 模板后缀
        'view_suffix' => 'htm',
    ],
    // 视图输出字符串内容替换
    'view_replace_str' => [
        '__ADMIN__' => '/static/admin',
        '__INDEX__' => '/static/index',
    ],

];
